import React from 'react'
import '../../Components/Cards/Cards.css'

export const Bottun = () => {
  return (
    <div className='order-button'>
      order now!
    </div>
  )
}
