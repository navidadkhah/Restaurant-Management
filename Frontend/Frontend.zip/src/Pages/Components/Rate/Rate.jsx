import React from 'react'
import '../Rate/Rate.css'
export const Rate = ({rate}) => {
  return (
    <div className='rate'>
      {rate}
    </div>
  )
}

